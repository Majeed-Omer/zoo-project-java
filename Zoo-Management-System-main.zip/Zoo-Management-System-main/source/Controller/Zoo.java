package m;
import java.io.IOException;

public class Zoo {
    public static void main(String args[]) throws IOException {
    	new view();
    }
}
