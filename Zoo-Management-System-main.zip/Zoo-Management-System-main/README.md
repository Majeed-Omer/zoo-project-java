# Zoo-Management-System
## Description
* This project is about managing a zoo with two user level. One where the managers can enter data for employees, animals, supplies and be able to see their incomes and expenditures. The other user level is for the users where they can see the list and information for the animals and are able to see the opening and closing time of the zoo as well as being able to buy tickets if wanted to visit the zoo with two types of tickets (normal and VIP). Finally managers, employees and users can create their own account.


## This system is for:
* Managers who own zoo.


## Purpose of this project:
* The purpose of this system is for those who manage zoos be able to see what animal they are having in their zoo as well as how much food their animals consume, in addition to identifiyng their workers and tasks. Finally this system helps visitors expect what to see in the zoo and information necessery before visiting.


## Level Users:
* Managers:
* Visitors:


## Requirements and Features
* Add/Delete/Update/view employee details.
* Add/Delete/update/view animal detail.
* Add/Delete/update/view supply details.
* User log in/ sign up.
* Users can Search for animal details.
* Ticket prices, details.
* Update/ clear income of the zoo.
* Update/ clear expenditure on the zoo.


## Tools and programs used for this project:
### Programming language:
* Java
### Tools:
* Eclipse
* Github


## Team Members
* Yahya Mewan Hassan: 
Team Advisor & programmer.
* Majeed Omer Majeed: 
Developer and programmer.
* Mohammed Hassan Rasul: 
Team Advisor & Supervisor.


## Deadline
* This project needs to finish over the course of two and a half months, with new requests added every week by the instructor(L.polla Fattah).




